<!--
Name  : Heri Priady
Site  : priadyheri.blogspot.com
Phone : 082386376942
Email : priady93@gmail.com
-->
<?php
session_start();
if($_SESSION['level']==NULL)
{
    header('location:login.php');
}
?>
<html>
    <head>
        <title>Login Aplikasi</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        
        <div style="font-weight: bold;">Hallo Selamat Dadatang! <a href="logout.php">Logout</a></div>
        Anda Berhasil Login dengan User <?php echo "<b>".$_SESSION['user']."</b> dan Level <b>".$_SESSION['level']."</b>"; ?>        
    
    </body>
</html>