<!DOCTYPE html>
<!--
Name  : Heri Priady
Site  : priadyheri.blogspot.com
Phone : 082386376942
Email : priady93@gmail.com
-->
<html>
    <head>
        <title>Login Aplikasi</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <?php
        if(!empty($_GET['error']))
        {
            echo 'Login Gagal Username/Password Salah!!!';
        }
        ?>
        <div style="font-weight: bold;">Form Login</div>
        <form action="cek_login.php" method="POST">
        <label>Username</label>
        <input type="text" name="username">
        <label>Password</label>
        <input type="password" name="password">
        <button type="submit">Login</button>
        </form>
    </body>
</html>
