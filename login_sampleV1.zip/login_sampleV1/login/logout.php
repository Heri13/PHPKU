<!--
Name  : Heri Priady
Site  : priadyheri.blogspot.com
Phone : 082386376942
Email : priady93@gmail.com
-->
<?php
session_start();
session_destroy();
header('location:index.php');