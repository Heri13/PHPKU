<!--
Name  : Heri Priady
Site  : priadyheri.blogspot.com
Phone : 082386376942
Email : priady93@gmail.com
-->
<?php
include '../koneksi.php';
if($_SERVER['REQUEST_METHOD']=="POST")
{
    $user=$_POST['username'];
    $pass=$_POST['password'];
    
    $login_query=mysqli_query($con, "SELECT * FROM login WHERE username='$user' AND password='$pass'");
    $login_cek= mysqli_num_rows($login_query);
    
    if($login_cek>0)
    {
        session_start();
        $r= mysqli_fetch_array($login_query);
        $_SESSION['level']=$r['level'];
        $_SESSION['user']=$pass;
        header('location:index.php');
    }else{
        header('location:login.php?error=logingagal');
    }
    
}

